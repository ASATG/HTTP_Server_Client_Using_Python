import http.client


while True:
    print("Menu:- ")
    print("1. Enter to get list of files on server: ")
    print("2. Enter to get file on server: ")
    print("3. Enter to post file to server: ")
    print("4. Enter to delete a file on server")
    print("5. To update a file")
    print("6. To get the size of server file")
    print("7. To get available options")
    print("8. To trace")
    print("9. To Connect")
    print("10 To disconnect")
    i = int(input("Enter your choice: "))
    if i == 1:
        
        headers = {'Content-type': 'text/plain'}
        path = '/server_files'
        connection.request('GET',path,headers = headers)
        response = connection.getresponse()
        print(f"Response status: {response.status}")
        print("Response body:")
        print(response.read().decode())
        
    elif i == 2:
        
        headers = {'Content-type': 'file/pdf'}
        i = input("Enter the name of the file: ")
        path = '/' + i
        connection.request('GET',path,headers = headers)
        response = connection.getresponse()
        if response.status == 200:
            with open("client_files/"+i,'wb') as file:
                file.write(response.read())
            print(f"pdf file successfully received and save as {i}")
        else:
            print(f"Failed to download PDF file. Status Code: {response.status}")
    elif i == 3:
        
        headers = {'Content-type': 'file/pdf'}
        i = input("Enter the name of the file: ")
        path = 'client_files/' + i

        with open(path, 'rb') as file:
            file_data = file.read()

        connection.request('POST','/'+i,file_data,headers)
        response = connection.getresponse()

        print(f"Response Status: {response.status}")
        print(f"Response body: ")
        print(response.read().decode())
        
    elif i == 4:
        
        i = input("Enter the name of the file: ")
        path = '/' + i
        connection.request('DELETE', path)
        response = connection.getresponse()

        print(f"Response Status: {response.status}")
        print(f"Response body: ")
        print(response.read().decode())
        
    elif i == 5:
          
        headers = {'Content-type': 'text/plain'}

        i = input("Enter the name of the file: ")
        path = '/' + i

        patch_data = input("Enter the content you want to add in this file")

        connection.request('PATCH', path, patch_data.encode('utf-8'), headers)
        response = connection.getresponse()

        print(f"Response status: {response.status}")
        print("Response body:")
        print(response.read().decode())

        
    elif i == 6:
        
        i = input("Enter the name of the file: ")
        path = '/' + i  
        connection.request('HEAD', path)
        response = connection.getresponse()

        print(f"Response status: {response.status}")
        print("Response headers:")
        print(response.getheaders())

        
    elif i == 7:
        
        connection.request('OPTIONS', '/')
        response = connection.getresponse()
        print(f"Response status: {response.status}")
        print("Response headers:")
        print(response.getheaders())

        
    elif i == 8:
        
        connection.request('TRACE', '/')
        response = connection.getresponse()
        print(f"Response status: {response.status}")
        print("Response headers:")
        print(response.read().decode())
        
    elif i == 9:
        connection = http.client.HTTPConnection('192.168.1.7', 8000)  
        connection.request('CONNECT', '/')  
        response = connection.getresponse()
        print(f"Response status: {response.status}")
        print("Response body:")
        print(response.read().decode())
    elif i == 10:
        connection.close()
        print("The connection has been closed")
        break
