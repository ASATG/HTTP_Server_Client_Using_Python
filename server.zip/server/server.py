from http.server import SimpleHTTPRequestHandler
from socketserver import TCPServer
import os

class CustomHandler(SimpleHTTPRequestHandler):
    def do_GET(self):
        if self.path =='/server_files':
            self.send_response(200)
            self.send_header('Content-type', 'text/html')
            self.end_headers()
            files = [file for file in os.listdir("server_files") if os.path.isfile(os.path.join("server_files", file))]
            send_text = "\n".join(files)
            self.wfile.write(send_text.encode())
        else:
            try:
                print(self.path[1:])
                with open("server_files/" + self.path[1:], 'rb') as file:
                    file_data = file.read()
                type = "pdf"
                self.send_response(200)
                self.send_header('Content-type', f'file/{type}')
                self.send_header('Content-disposition', f'attachment; filename={self.path[1:]}')
                self.end_headers()

                self.wfile.write(file_data)
            except FileNotFoundError:
                self.send_response(404)
                self.send_header('Content-type', 'text/plain')
                self.end_headers()
                response_text = "File not found on the server."
                self.wfile.write(response_text.encode('utf-8'))

    def do_POST(self):
        content_length = int(self.headers['Content-Length'])
        file_data = self.rfile.read(content_length)
        with open("server_files/" + self.path[1:], 'wb') as file:
            file.write(file_data)

        self.send_response(200)
        self.send_header('Content-type', 'text/html')
        self.end_headers()
        self.wfile.write(b'File successfully loaded')

    def do_DELETE(self):
        try:
            os.remove("server_files" + self.path)
            self.send_response(200)
            self.send_header('Content-type', 'text/html')
            self.end_headers()
            self.wfile.write(b'File successfully deleted')
        except FileNotFoundError:
            self.send_response(404)
            self.send_header('Content-type', 'text/html')
            self.end_headers()
            self.wfile.write(b'File not found on server')

    def do_PATCH(self):
        try:
            content_length = int(self.headers['Content-Length'])
            patch_data = self.rfile.read(content_length)

            with open("server_files" + self.path, 'r') as file:
                original_content = file.read()

            updated_content = original_content + patch_data.decode('utf-8')

            with open("server_files" + self.path, 'w') as file:
                file.write(updated_content)

            self.send_response(200)
            self.send_header('Content-type', 'text/plain')
            self.end_headers()
            response_text = "File successfully patched."
            self.wfile.write(response_text.encode('utf-8'))
        except FileNotFoundError:
            self.send_response(404)
            self.send_header('Content-type', 'text/plain')
            self.end_headers()
            response_text = "File not found on the server."
            self.wfile.write(response_text.encode('utf-8'))

    def do_HEAD(self):
        try:
            file_path = "server_files" + self.path
            file_size = os.path.getsize(file_path)

            self.send_response(200)
            self.send_header('Content-type', 'text/plain')
            self.send_header('Content-length', str(file_size))
            self.end_headers()
        except FileNotFoundError:
            self.send_response(404)
            self.send_header('Content-type', 'text/plain')
            self.end_headers()
            response_text = "File not found on the server."
            self.wfile.write(response_text.encode('utf-8'))

    def do_OPTIONS(self):
        self.send_response(200)
        self.send_header('Content-type', 'text/plain')
        self.send_header('Access-Control-Allow-Methods', 'GET, POST, DELETE, PATCH, HEAD, OPTIONS, TRACE, CONNECT')
        self.end_headers()

    def do_TRACE(self):
        self.send_response(200)
        self.send_header('Content-type', 'message/http')
        self.end_headers()
        request_headers = str(self.headers).encode('utf-8')
        self.wfile.write(request_headers)


    def do_CONNECT(self):
        self.send_response(200)
        self.send_header('Content-type', 'text/plain')
        self.end_headers()
        self.wfile.write(b'CONNECT request received')

if __name__ == "__main__":
    HOST, PORT = '0.0.0.0', 8000  # '0.0.0.0' allows connections from any IP address
    with TCPServer((HOST, PORT), CustomHandler) as httpd:
        print(f"Serving on {HOST}:{PORT}")
        httpd.serve_forever()
